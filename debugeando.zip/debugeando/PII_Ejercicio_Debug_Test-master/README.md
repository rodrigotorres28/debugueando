# Universidad Católica del Uruguay
## Facultad de Ingeniería y Tecnologías
### Programación II
Código de ejemplo del tema "debug y test"
